# Recruitment & Placement Management System - UI Prototype
Static HTML + CSS prototype (no backend). 
**How to open:** unzip, then double-click `login.html` in any browser (Chrome/Edge/Firefox). Click Login to reach the dashboard; use the left sidebar to move between modules.
**Pages:** login, dashboard, candidates, candidate-form, candidate-details, companies, jobs, job-form, applications, interviews, placement-process, reports.
**Flows:** Candidates > Add > Details > Applications | Jobs > Create Job > View Applications | Applications > Schedule Interview > Add Feedback > Offer/Joining > Reports.
**Files:** `css/style.css` is shared by all pages; `images/logo.png` is the logo. Replace it with your own logo if needed.
